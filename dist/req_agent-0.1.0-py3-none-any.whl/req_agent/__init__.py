"""req-agent: One-sentence requirement → full PRD document agent."""
__version__ = "0.1.0"
